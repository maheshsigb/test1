{
    'name': 'Hospital Management',
    'version': '1.0.0',
    'sequence': -100,
    'author': 'Azhar Saleem',
    'website': 'www.azharsaleem.com',
    'category': 'Health',
    'summary': 'Hospital management system',
    'description': 'Hospital management system',
    'depends': [],
    'data': [
        'security/ir.model.access.csv',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    'license': 'LGPL-3',
}